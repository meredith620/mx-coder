#!/usr/bin/env node
import { spawn } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { fileURLToPath } from 'url';
import { IPCClient } from './ipc/client.js';
import { attachSession } from './attach.js';
import { parseCLIArgs } from './cli-parser.js';
import { BUILD_GIT_HASH, BUILD_VERSION } from './generated/build-info.js';
import { getCLIPlugin, getDefaultCLIPluginName } from './plugins/cli/registry.js';
import { getClaudeSessionPath, hasClaudeSession } from './plugins/cli/claude-code.js';
import { getIMPluginFactory, getDefaultIMPluginName } from './plugins/im/registry.js';
import type { Session } from './types.js';

const SOCKET_PATH = process.env.MM_CODER_SOCKET ?? path.join(os.tmpdir(), 'mm-coder-daemon.sock');
const PID_FILE = process.env.MM_CODER_PID_FILE ?? path.join(os.tmpdir(), 'mm-coder-daemon.pid');
const PERSISTENCE_PATH = process.env.MM_CODER_SESSIONS ?? path.join(os.homedir(), '.mm-coder', 'sessions.json');
const LOG_PATH = process.env.MM_CODER_LOG ?? path.join(os.homedir(), '.mm-coder', 'daemon.log');
const VERSION = BUILD_VERSION;
const GIT_HASH = BUILD_GIT_HASH;

function printVersion() {
  console.log(`mm-coder ${VERSION} (${GIT_HASH})`);
}

async function main() {
  const argv = process.argv.slice(2);

  if (argv.length === 0 || argv[0] === '--help' || argv[0] === '-h') {
    printHelp();
    process.exit(0);
  }

  if (argv[0] === '--version' || argv[0] === '-v') {
    printVersion();
    process.exit(0);
  }

  try {
    if (argv[0] === 'start-fg') {
      await handleStartForeground(argv.slice(1));
      return;
    }

    const parsed = parseCLIArgs(argv);

    switch (parsed.command) {
      case 'start':
        await handleStart(parsed.args);
        break;
      case 'stop':
        await handleStop();
        break;
      case 'restart':
        await handleRestart(parsed.args);
        break;
      case 'create':
        await handleCreate(parsed.args);
        break;
      case 'attach':
        await handleAttach(parsed.args);
        break;
      case 'list':
        await handleList();
        break;
      case 'takeover-status':
        await handleTakeoverStatus(parsed.args);
        break;
      case 'takeover-cancel':
        await handleTakeoverCancel(parsed.args);
        break;
      case 'status':
        await handleStatus(parsed.args);
        break;
      case 'remove':
        await handleRemove(parsed.args);
        break;
      case 'diagnose':
        await handleDiagnose(parsed.args);
        break;
      case 'import':
        await handleImport(parsed.args);
        break;
      case 'completion':
        await handleCompletion(parsed.args);
        break;
      case 'im':
        await handleIm(parsed.subcommand!, parsed.args);
        break;
      case 'tui':
        console.error('tui: not yet implemented');
        process.exit(1);
        break;
      default:
        console.error(`Unknown command: ${parsed.command}`);
        process.exit(1);
    }
  } catch (err) {
    console.error(`Error: ${(err as Error).message}`);
    process.exit(1);
  }
}

function printHelp() {
  console.log(`
mm-coder - Multi-modal Claude Code session manager

USAGE:
  mm-coder <command> [options]

COMMANDS:
  start                           Start daemon in background
  start-fg                        Start daemon in foreground and print logs
  stop                            Stop the running daemon
  restart                         Restart the daemon
  create <name> [-n|--name <name>] [-w|--workdir <path>] [-C|--cli <name>]
                                  Create a new session
  attach <name> [-n|--name <name>]  Attach to a session
  diagnose <name>                   Print local diagnostic info for a session
  takeover-status <name>            Show takeover request state
  takeover-cancel <name>            Cancel a pending takeover request
  list                            List all sessions
  status [name] [-n|--name <name>]  Show daemon/session status
  remove <name> [-n|--name <name>]  Remove a session
  import <sessionId> [-s|--sessionId <id>] -w <path> [-n|--name <name>] [-C|--cli <name>]
                                  Import external session
  completion <bash|zsh|sessions>   Print shell completion script or session names
  im init [-p|--plugin <name>] [-c|--config <path>]
                                  Create IM config template
  im verify [-p|--plugin <name>] [-c|--config <path>]
                                  Verify IM connectivity
  im run <sessionName>            Run IM worker for a session
  --help, -h                      Show this help
  --version, -v                   Show version info

EXAMPLES:
  mm-coder start
  mm-coder start-fg
  mm-coder create bug-fix -w ~/myapp
  mm-coder attach bug-fix -n my-session
  mm-coder diagnose bug-fix
  mm-coder takeover-status bug-fix
  mm-coder takeover-cancel bug-fix
  mm-coder list
  mm-coder status bug-fix -n my-session
  mm-coder remove bug-fix -n my-session
  mm-coder completion bash
  mm-coder completion zsh
  mm-coder completion sessions
  mm-coder im init -p discord
  mm-coder im verify
  mm-coder im init -c ~/.mm-coder/discord.json
`.trim());
}

function getCompletionCommands(): string[] {
  return [
    'start',
    'stop',
    'restart',
    'create',
    'attach',
    'diagnose',
    'takeover-status',
    'takeover-cancel',
    'list',
    'status',
    'remove',
    'import',
    'completion',
    'im',
    'tui',
  ];
}

function renderBashCompletion(): string {
  const commands = getCompletionCommands().join(' ');
  return `# bash completion for mm-coder
_mm_coder_completions() {
  local cur prev words cword
  cur="\${COMP_WORDS[COMP_CWORD]}"
  prev="\${COMP_WORDS[COMP_CWORD-1]}"

  if [[ \${COMP_CWORD} -eq 1 ]]; then
    COMPREPLY=( $(compgen -W "${commands}" -- "\${cur}") )
    return 0
  fi

  if [[ \${COMP_WORDS[1]} == "completion" ]]; then
    COMPREPLY=( $(compgen -W "bash zsh sessions" -- "\${cur}") )
    return 0
  fi
}
complete -F _mm_coder_completions mm-coder
`;
}

function renderZshCompletion(): string {
  const commands = getCompletionCommands().map((command) => `'${command}:${command}'`).join(' ');
  return `#compdef mm-coder

_mm_coder() {
  local -a commands
  commands=(
    ${commands}
  )

  if (( CURRENT == 2 )); then
    _describe 'command' commands
    return
  fi

  if [[ \${words[2]} == completion ]]; then
    _values 'shell' bash zsh sessions
    return
  fi
}

_mm_coder "$@"
`;
}

async function handleCompletion(args: Record<string, string | undefined>) {
  const shell = args.shell;

  if (shell === 'sessions') {
    const client = new IPCClient(SOCKET_PATH);
    await client.connect();
    const res = await client.send('list', {});
    await client.close();

    if (!res.ok) {
      throw new Error(`Failed to load sessions for completion: ${res.error!.message}`);
    }

    const sessions = res.data.sessions as Array<Record<string, unknown>>;
    const names = sessions
      .map((session) => session.name)
      .filter((name): name is string => typeof name === 'string');
    process.stdout.write(names.join('\n'));
    return;
  }

  if (shell !== 'bash' && shell !== 'zsh') {
    throw new Error('Missing or unsupported shell. Usage: mm-coder completion <bash|zsh|sessions>');
  }

  if (shell === 'bash') {
    process.stdout.write(renderBashCompletion());
    return;
  }

  process.stdout.write(renderZshCompletion());
}

async function handleStart(args: Record<string, string | undefined>) {
  if (fs.existsSync(PID_FILE)) {
    const pid = parseInt(fs.readFileSync(PID_FILE, 'utf-8').trim(), 10);
    try {
      process.kill(pid, 0);
      console.log(`Daemon already running (PID ${pid})`);
      return;
    } catch {
      fs.unlinkSync(PID_FILE);
    }
  }

  fs.mkdirSync(path.dirname(PERSISTENCE_PATH), { recursive: true });

  const imPluginName = args.plugin ?? getDefaultIMPluginName();
  const imConfigPath = args.config;
  const childArgs = [
    path.join(path.dirname(fileURLToPath(import.meta.url)), 'daemon-main.js'),
    SOCKET_PATH,
    PID_FILE,
    PERSISTENCE_PATH,
    imConfigPath ?? '',
    imPluginName,
    LOG_PATH,
  ];

  const child = spawn(process.execPath, childArgs, {
    detached: true,
    stdio: 'ignore',
  });

  child.unref();
  console.log(`Daemon started (PID ${child.pid})`);
  console.log(`Log file: ${LOG_PATH}`);
}

async function handleStartForeground(argv: string[]) {
  const parsed = argv.length > 0 ? parseCLIArgs(['start', ...argv]) : { command: 'start', args: {} as Record<string, string | undefined> };
  const args = parsed.args;
  const imPluginName = args.plugin ?? getDefaultIMPluginName();
  const imConfigPath = args.config;
  const childArgs = [
    path.join(path.dirname(fileURLToPath(import.meta.url)), 'daemon-main.js'),
    SOCKET_PATH,
    '',
    PERSISTENCE_PATH,
    imConfigPath ?? '',
    imPluginName,
    LOG_PATH,
  ];

  console.log(`Starting daemon in foreground. Log file: ${LOG_PATH}`);
  const child = spawn(process.execPath, childArgs, {
    stdio: 'inherit',
  });

  await new Promise<number>((resolve, reject) => {
    child.on('close', code => resolve(code ?? 0));
    child.on('error', reject);
  });
}

async function handleStop() {
  if (!fs.existsSync(PID_FILE)) {
    console.log('Daemon is not running');
    return;
  }

  const pid = parseInt(fs.readFileSync(PID_FILE, 'utf-8').trim(), 10);
  try {
    process.kill(pid, 'SIGTERM');
    console.log(`Daemon stopped (PID ${pid})`);
  } catch {
    try { fs.unlinkSync(PID_FILE); } catch { /* ignore */ }
    console.log('Daemon was not running (stale PID file removed)');
  }
}

async function handleRestart(args: Record<string, string | undefined>) {
  await handleStop();
  await new Promise(resolve => setTimeout(resolve, 500));
  await handleStart(args);
}

async function handleCreate(args: Record<string, string | undefined>) {
  const name = args.name;
  const workdir = args.workdir ?? process.cwd();
  const cli = args.cli ?? getDefaultCLIPluginName();

  if (!name) {
    throw new Error('Missing required argument: name');
  }

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();

  const res = await client.send('create', { name, workdir, cli });
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to create session: ${res.error!.message}`);
  }

  console.log(`Session '${name}' created`);
}

async function handleAttach(args: Record<string, string | undefined>) {
  const name = args.name;

  if (!name) {
    throw new Error('Missing required argument: name');
  }

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();
  const res = await client.send('status', {});
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to get status: ${res.error!.message}`);
  }

  const sessions = res.data!.sessions as Array<Record<string, unknown>>;
  const sessionSummary = sessions.find(s => s.name === name);
  if (!sessionSummary) {
    throw new Error(`Session not found: ${name}`);
  }

  const cliPluginName = typeof sessionSummary.cliPlugin === 'string' ? sessionSummary.cliPlugin : getDefaultCLIPluginName();
  const initState = typeof sessionSummary.initState === 'string' ? sessionSummary.initState as Session['initState'] : 'uninitialized';
  const session: Session = {
    name,
    sessionId: typeof sessionSummary.sessionId === 'string' ? sessionSummary.sessionId : '',
    cliPlugin: cliPluginName,
    workdir: typeof sessionSummary.workdir === 'string' ? sessionSummary.workdir : process.cwd(),
    status: (sessionSummary.status as Session['status']) ?? 'idle',
    lifecycleStatus: (sessionSummary.lifecycleStatus as Session['lifecycleStatus']) ?? 'active',
    initState,
    runtimeState: (sessionSummary.runtimeState as Session['runtimeState']) ?? (typeof sessionSummary.status === 'string' && sessionSummary.status === 'attached' ? 'attached_terminal' : 'cold'),
    revision: 0,
    spawnGeneration: 0,
    attachedPid: null,
    imWorkerPid: null,
    imWorkerCrashCount: 0,
    imBindings: [],
    messageQueue: [],
    createdAt: sessionSummary.createdAt instanceof Date ? sessionSummary.createdAt : new Date(String(sessionSummary.createdAt ?? Date.now())),
    lastActivityAt: new Date(),
  };

  if (initState !== 'uninitialized' && !session.sessionId) {
    throw new Error(`Session ${name} is missing sessionId`);
  }

  const cliPlugin = getCLIPlugin(cliPluginName);
  const cmdSpec = cliPlugin.buildAttachCommand(session);

  await attachSession({
    socketPath: SOCKET_PATH,
    sessionName: name,
    cliCommand: cmdSpec.command,
    cliArgs: cmdSpec.args,
    workdir: session.workdir,
  });
}

async function handleDiagnose(args: Record<string, string | undefined>) {
  const name = args.name;
  if (!name) {
    throw new Error('Missing required argument: name');
  }

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();
  const res = await client.send('status', {});
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to get status: ${res.error!.message}`);
  }

  const sessions = res.data!.sessions as Array<Record<string, unknown>>;
  const session = sessions.find(s => s.name === name);
  if (!session) {
    throw new Error(`Session not found: ${name}`);
  }

  const workdir = typeof session.workdir === 'string' ? session.workdir : process.cwd();
  const sessionId = typeof session.sessionId === 'string' ? session.sessionId : '';
  const sessionFile = getClaudeSessionPath(workdir, sessionId);
  const hasLocalSession = hasClaudeSession(workdir, sessionId);
  const commandMode = hasLocalSession ? '--resume' : '--session-id';

  console.log(JSON.stringify({
    name,
    sessionId,
    status: session.status,
    lifecycleStatus: session.lifecycleStatus,
    initState: session.initState,
    workdir,
    cwd: process.cwd(),
    localClaudeSessionPath: sessionFile,
    localClaudeSessionExists: hasLocalSession,
    nextAttachMode: commandMode,
    logPath: LOG_PATH,
    socketPath: SOCKET_PATH,
    persistencePath: PERSISTENCE_PATH,
  }, null, 2));
}

async function handleList() {
  const client = new IPCClient(SOCKET_PATH);
  await client.connect();

  const res = await client.send('list', {});
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to list sessions: ${res.error!.message}`);
  }

  const sessions = res.data!.sessions as Array<Record<string, unknown>>;
  if (sessions.length === 0) {
    console.log('No sessions');
    return;
  }

  console.log('Sessions:');
  for (const s of sessions) {
    console.log(`  ${s.name} (${s.status}) - ${s.workdir}`);
  }
}

async function handleTakeoverStatus(args: Record<string, string | undefined>) {
  const name = args.name;
  if (!name) throw new Error('Missing required argument: name');

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();
  const res = await client.send('takeoverStatus', { name });
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to get takeover status: ${res.error!.message}`);
  }

  console.log(JSON.stringify(res.data, null, 2));
}

async function handleTakeoverCancel(args: Record<string, string | undefined>) {
  const name = args.name;
  if (!name) throw new Error('Missing required argument: name');

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();
  const res = await client.send('takeoverCancel', { name });
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to cancel takeover: ${res.error!.message}`);
  }

  console.log(`Takeover for '${name}' cancelled`);
}

function isBusyRuntimeState(runtimeState: string | undefined): boolean {
  return runtimeState === 'running'
    || runtimeState === 'waiting_approval'
    || runtimeState === 'attached_terminal'
    || runtimeState === 'takeover_pending'
    || runtimeState === 'recovering';
}

async function handleStatus(args: Record<string, string | undefined>) {
  const name = args.name;

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();

  const res = await client.send('status', {});
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to get status: ${res.error!.message}`);
  }

  console.log(`Daemon PID: ${res.data!.pid}`);
  const sessions = res.data!.sessions as Array<Record<string, unknown>>;

  if (name) {
    const s = sessions.find(s => s.name === name);
    if (!s) {
      throw new Error(`Session not found: ${name}`);
    }
    const runtimeState = s.runtimeState as string | undefined;
    const busy = isBusyRuntimeState(runtimeState);
    console.log(JSON.stringify({
      ...s,
      busy,
      idle: !busy,
    }, null, 2));
  } else {
    console.log(`Sessions: ${sessions.length}`);
    for (const s of sessions) {
      const runtimeState = (s.runtimeState as string | undefined) ?? (s.status === 'attached' ? 'attached_terminal' : 'cold');
      const busy = isBusyRuntimeState(runtimeState);
      console.log(`  ${s.name} (${s.status}, runtime=${runtimeState}, ${busy ? 'busy' : 'idle'})`);
    }
  }
}

async function handleRemove(args: Record<string, string | undefined>) {
  const name = args.name;

  if (!name) {
    throw new Error('Missing required argument: name');
  }

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();

  const res = await client.send('remove', { name });
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to remove session: ${res.error!.message}`);
  }

  console.log(`Session '${name}' removed`);
}

async function handleImport(args: Record<string, string | undefined>) {
  const sessionId = args.sessionId;
  const workdir = args.workdir ?? process.cwd();
  const name = args.name;
  const cli = args.cli ?? getDefaultCLIPluginName();

  if (!sessionId) {
    throw new Error('Missing required argument: sessionId');
  }

  const client = new IPCClient(SOCKET_PATH);
  await client.connect();

  const res = await client.send('import', { sessionId, workdir, name, cli });
  await client.close();

  if (!res.ok) {
    throw new Error(`Failed to import session: ${res.error!.message}`);
  }

  const imported = res.data!.session as Record<string, unknown>;
  console.log(`Session imported as '${imported.name}'`);
}

async function handleIm(subcommand: string, args: Record<string, string | undefined>) {
  switch (subcommand) {
    case 'init':
      await handleImInit(args);
      break;
    case 'verify':
      await handleImVerify(args);
      break;
    case 'run':
      console.error('im run: not yet implemented');
      process.exit(1);
      break;
    default:
      console.error(`Unknown im subcommand: ${subcommand}`);
      process.exit(1);
  }
}

async function handleImInit(args: Record<string, string | undefined>) {
  const pluginName = args.plugin ?? getDefaultIMPluginName();
  const factory = getIMPluginFactory(pluginName);
  const configPath = args.config ?? factory.getDefaultConfigPath();

  try {
    factory.writeConfigTemplate(configPath);
    console.log(`Config template written to: ${configPath}`);
    console.log('');
    console.log('Next steps:');
    console.log(`  1. Edit ${configPath}`);
    console.log(`  2. Fill in your ${pluginName} configuration`);
    console.log(`  3. Run: mm-coder im verify -p ${pluginName}`);
  } catch (err) {
    throw new Error((err as Error).message);
  }
}

async function handleImVerify(args: Record<string, string | undefined>) {
  const pluginName = args.plugin ?? getDefaultIMPluginName();
  const factory = getIMPluginFactory(pluginName);
  const configPath = args.config;

  console.log(`Verifying ${pluginName} connection...`);
  const result = await factory.verifyConnection(configPath);

  console.log('Connection OK');
  console.log(`  Plugin: ${pluginName}`);
  console.log(`  Bot user ID: ${result.botUserId}`);
}

main().catch(err => {
  console.error(`Fatal error: ${err.message}`);
  process.exit(1);
});
