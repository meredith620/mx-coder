import { describe, test, expect, beforeEach, afterEach } from 'vitest';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { SessionRegistry } from '../../src/session-registry.js';
import { IMMessageDispatcher } from '../../src/im-message-dispatcher.js';
import { IMWorkerManager } from '../../src/im-worker-manager.js';
import { MockIMPlugin } from '../helpers/mock-im-plugin.js';
import { MockCLIPlugin } from '../helpers/mock-cli-plugin.js';
import { ApprovalHandler } from '../../src/approval-handler.js';
import { ApprovalManager } from '../../src/approval-manager.js';

describe('IM 消息处理 E2E', () => {
  let tmpDir: string;
  let registry: SessionRegistry;
  let mockIM: MockIMPlugin;
  let dispatcher: IMMessageDispatcher;
  let approvalHandler: ApprovalHandler | undefined;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mm-e2e-test-'));
    registry = new SessionRegistry();
    mockIM = new MockIMPlugin();
  });

  afterEach(async () => {
    dispatcher?.stop();
    await approvalHandler?.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  test('IM 消息 → mock claude → IM 回复', async () => {
    // Create a mock claude CLI that outputs a fixed stream-json event
    const mockCli = path.join(tmpDir, 'mock-claude.sh');
    fs.writeFileSync(mockCli, [
      '#!/bin/sh',
      'while IFS= read -r line; do',
      '  echo \'{"type":"assistant","payload":{"message":{"content":[{"type":"text","text":"Hello from mock claude"}]}}}\'',
      '  echo \'{"type":"result","payload":{"subtype":"success","result":"done"}}\'',
      'done',
    ].join('\n'), { mode: 0o755 });

    registry.create('test-session', { workdir: tmpDir, cliPlugin: 'mock' });

    dispatcher = new IMMessageDispatcher({
      registry,
      imPlugin: mockIM,
      imTarget: { plugin: 'mock', threadId: 'thread-1' },
      workerManager: new IMWorkerManager(new MockCLIPlugin(mockCli), registry),
    });

    dispatcher.start();

    // Enqueue a message
    registry.enqueueIMMessage('test-session', {
      plugin: 'mock',
      threadId: 'thread-1',
      messageId: 'msg-1',
      userId: 'user-1',
      text: 'hello',
      dedupeKey: 'dedup-1',
    });

    // Wait for processing
    await new Promise(resolve => setTimeout(resolve, 500));

    // Verify IM received a live message with the response
    expect(mockIM.liveMessages.size).toBeGreaterThan(0);
    const messages = [...mockIM.liveMessages.values()];
    expect(messages.some(m => m.includes('Hello from mock claude'))).toBe(true);
  }, 10000);

  test('审批通过后同一 worker 继续输出后续结果，不会停在单轮', async () => {
    const approvalSocketPath = path.join(tmpDir, 'approval.sock');
    const approvalMgr = new ApprovalManager({
      autoAllowCapabilities: [],
      autoAskCapabilities: ['file_write'],
      autoDenyCapabilities: [],
      autoDenyPatterns: [],
      timeoutSeconds: 10,
    });
    approvalHandler = new ApprovalHandler({
      socketPath: approvalSocketPath,
      approvalManager: approvalMgr,
      imPlugin: mockIM,
      imTarget: { plugin: 'mock', threadId: 'thread-approval-continue' },
    });
    await approvalHandler.listen();

    const workerScript = path.join(tmpDir, 'mock-claude-approval-continue.sh');
    fs.writeFileSync(workerScript, [
      '#!/bin/sh',
      'while IFS= read -r line; do',
      `  RESPONSE=$(node -e "`,
      `const net = require('net');`,
      `const s = net.createConnection('${approvalSocketPath}');`,
      `let buf = '';`,
      `s.on('data', d => { buf += d.toString(); });`,
      `s.on('connect', () => {`,
      `  s.write(JSON.stringify({`,
      `    jsonrpc:'2.0', id:1, method:'tools/call',`,
      `    params:{ name:'can_use_tool', arguments:{`,
      `      tool_name:'Edit', tool_input:{path:'/tmp/a.txt'}, capability:'file_write',`,
      `      session_id:'sess-continue', message_id:'msg-continue', tool_use_id:'tool-continue'`,
      `    }}`,
      `  }) + '\\n');`,
      `});`,
      `setTimeout(() => { console.log(buf.trim()); s.destroy(); }, 1500);`,
      `" 2>/dev/null)`,
      `  ALLOW=$(printf "%s" "$RESPONSE" | node -e "const d=require('fs').readFileSync('/dev/stdin','utf8'); const r=JSON.parse(d||'{}'); console.log(r.result&&r.result.allow?'yes':'no')")`,
      '  if [ "$ALLOW" = "yes" ]; then',
      '    echo \'{"type":"assistant","payload":{"message":{"content":[{"type":"text","text":"step 1 after approval"}]}}}\'',
      '    echo \'{"type":"assistant","payload":{"message":{"content":[{"type":"text","text":"step 2 still running"}]}}}\'',
      '    echo \'{"type":"result","payload":{"subtype":"success","result":"done"}}\'',
      '  fi',
      'done',
    ].join('\n'), { mode: 0o755 });

    registry.create('approval-continue-session', { workdir: tmpDir, cliPlugin: 'mock' });

    dispatcher = new IMMessageDispatcher({
      registry,
      imPlugin: mockIM,
      imTarget: { plugin: 'mock', threadId: 'thread-approval-continue' },
      workerManager: new IMWorkerManager(new MockCLIPlugin(workerScript), registry, approvalSocketPath),
      pollIntervalMs: 50,
    });

    dispatcher.start();

    registry.enqueueIMMessage('approval-continue-session', {
      plugin: 'mock',
      threadId: 'thread-approval-continue',
      messageId: 'msg-approval-continue',
      userId: 'user-1',
      text: 'continue after approval',
      dedupeKey: 'dedup-approval-continue',
    });

    await new Promise(resolve => setTimeout(resolve, 1200));
    expect(mockIM.approvalRequests).toHaveLength(1);

    const pending = approvalMgr.getAllApprovalStates()[0];
    expect(pending).toBeDefined();
    await approvalMgr.decide(pending.requestId, { decision: 'approved', scope: 'once' });

    await new Promise(resolve => setTimeout(resolve, 2200));

    const messages = [...mockIM.liveMessages.values()];
    expect(messages.some(m => m.includes('step 1 after approval'))).toBe(true);
    expect(messages.some(m => m.includes('step 2 still running'))).toBe(true);
    expect(registry.get('approval-continue-session')?.messageQueue[0]?.status).toBe('completed');
  }, 15000);
});
